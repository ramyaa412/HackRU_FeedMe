var fs = require('fs');
var APP_ID;
var AlexaSkill = require('./AlexaSkill');

var SDK = function () {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
SDK.prototype = Object.create(AlexaSkill.prototype);
SDK.prototype.constructor = SDK;

SDK.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    var speechOutput = "Welcome to the Nexmo Alexa Text Skill";
    var repromptText = "Welcome to the Nexmo Alexa Text Skill";
    response.ask(speechOutput, repromptText);
};

SDK.prototype.intentHandlers = {
    "SendTextIntent": function(intent, session, response) {

        var contacts;
        //Read APP_ID from credential file
        fs.readFile('nexmoCredentials.json', 'utf8', function(err, data){
            if(err){
                console.log("There was an error reading the crednetial file: " + err);
                // This is for development purposes, overwrite with a user-friendly message before release!
                response.tell("There seems to be a problem with your credential file. Check your credential file.");
            }
            data = JSON.parse(data);
            APP_ID = data.appId;
            contacts = data.contacts;
            console.log("user contacts are: " + contacts);
            lookup(contacts);
        })  

        var lookup = function(contacts){
            var contactName = intent.slots.destination.value.toLowerCase();
            if(contacts[contactName]){
                response.sendTextMessage(contacts[contactName], contactName, intent.slots.message.value);
            } else {
                response.ask("I didn't find a contact with that name. Please try again", "Please try again");    
            }
        }
    },
    "AMAZON.HelpIntent": function (intent, session, response) {
        response.ask("Welcome to the Nexmo Alexa Text SDK. You can say ask texting skill to text Jared the message hello", 
            "say ask texting skill to text Jared the message hello");
    }
};

exports.handler = function (event, context) {
    var sdk = new SDK();
    sdk.execute(event, context);
};

