const fs = require("fs");
const nexmo = require("easynexmo");
const Promise = require("bluebird");
var nexmoNumber;

var sendMessage = function(to, toName, message){
	return new Promise(function(resolve, reject){
		nexmo.sendTextMessage(nexmoNumber, "1" + to, message, {}, function(err, res){
			console.log("resolution from sending text was: ");
			console.log(res);
			if(err){
				console.log("error from sending text message: " + err);
			}
			if(res.messages[0].status != 0){
				console.log("there was a problem with your request: " + res.messages[0]["error-text"]);
				reject("Error!");
			}
			resolve("Sent text message!");
		});
	})
}

var getCredentials = function(){
	return new Promise(function( resolve, reject){
		fs.readFile('nexmoCredentials.json', 'utf8', function(err, data){
		if(err){
			reject(err);
		}
		data = JSON.parse(data);
		nexmo.initialize(data.nexmoKey, data.nexmoSecret, true);
		nexmoNumber = data.nexmoNumber;
		resolve("Success!");
		})	
	});
}

exports.sendText = function(to, toName, message, cb){
	getCredentials().then(function(data){
	return sendMessage(to, toName, message);
	}).then(function(secondPromise){
		cb("Success!");
	}).catch(function(err){
		cb("Error!");
	});
}